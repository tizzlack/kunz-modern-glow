import { Heart, Phone, Facebook, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Logo and Description */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Kunz Gesundheit</h3>
                <p className="text-primary-foreground/80">Berufsmasseur</p>
              </div>
            </div>
            <p className="text-primary-foreground/80 leading-relaxed">
              Professionelle Massage- und Gesundheitsdienstleistungen für Ihr körperliches, 
              geistiges und seelisches Wohlbefinden.
            </p>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            <h4 className="text-xl font-semibold mb-4">Kontakt</h4>
            <div className="space-y-4">
              <div>
                <h5 className="font-medium mb-2">Yannick Cyrill Kunz</h5>
                <p className="text-primary-foreground/80">Dipl. Berufsmasseur</p>
                <p className="text-primary-foreground/80">Dipl. Schulmedizin Grundlage</p>
                <p className="text-primary-foreground/80">Zertifizierter Mixed Martial Arts Trainer</p>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5" />
                <a href="tel:0763611265" className="hover:text-accent transition-colors">
                  076 361 12 65
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links and Social */}
          <div className="space-y-6">
            <h4 className="text-xl font-semibold mb-4">Folgen Sie uns</h4>
            <div className="flex gap-4">
              <Button
                variant="outline"
                size="icon"
                className="border-white/30 text-white hover:bg-white hover:text-primary"
                onClick={() => window.open('https://www.facebook.com/profile.php?id=61571743576514', '_blank')}
              >
                <Facebook className="w-5 h-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="border-white/30 text-white hover:bg-white hover:text-primary"
              >
                <Instagram className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="pt-6">
              <h5 className="font-medium mb-3">Motto</h5>
              <p className="text-accent font-medium text-lg">
                "Gesundheit ist ein Prozess"
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 mt-12 pt-8 text-center">
          <p className="text-primary-foreground/60">
            © 2024 Kunz Gesundheit. Alle Rechte vorbehalten.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
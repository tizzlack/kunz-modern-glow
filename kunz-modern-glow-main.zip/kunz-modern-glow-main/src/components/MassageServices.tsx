import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Heart, Sparkles, Calendar } from "lucide-react";

const MassageServices = () => {
  const massageServices = [
    {
      icon: Heart,
      title: "Erholungsmassage",
      duration: "1 Std. 30 Min.",
      price: "CHF 119",
      description: "Eine umfassende Massage für tiefe Entspannung und Regeneration. Perfekt um Stress abzubauen und neue Energie zu tanken.",
      features: ["Ganzkörpermassage", "Entspannungsmusik", "Aromaöle", "Nachruhe"],
      bookingUrl: "https://www.kunz-gesundheit.ch/booking-calendar/erholungsmassage",
      popular: false
    },
    {
      icon: Sparkles,
      title: "Massage Abos",
      duration: "1 Std.",
      price: "CHF 100",
      description: "Regelmässige Massagen für nachhaltiges Wohlbefinden. Spare mit unseren flexiblen Abo-Angeboten und investiere in deine Gesundheit.",
      features: ["Flexibler Termin", "Vergünstigter Preis", "Personalisiert", "Langfristige Betreuung"],
      bookingUrl: "https://www.kunz-gesundheit.ch/booking-calendar/massage-abos",
      popular: true
    },
    {
      icon: Calendar,
      title: "Gesundheit kommt von innen",
      duration: "30 Min.",
      price: "Beratung",
      description: "Eine persönliche Beratung für ganzheitliche Gesundheit. Entdecke, wie innere Balance zu äusserem Wohlbefinden führt.",
      features: ["Gesundheitsanalyse", "Persönliche Beratung", "Individuelle Tipps", "Nachbetreuung"],
      bookingUrl: "https://www.kunz-gesundheit.ch/booking-calendar/gesundheit-kommt-von-innen",
      popular: false
    }
  ];

  return (
    <section id="massage-services" className="py-20 lg:py-32 bg-professional-neutral">{/* ... keep existing code */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Für Körper und Geist: Dein ganzheitliches Massageangebot
          </h2>
          <div className="w-20 h-1 bg-gradient-primary rounded-full mx-auto mb-8"></div>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Wähle aus unseren professionellen Massage-Angeboten und finde die perfekte Behandlung für deine Bedürfnisse.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {massageServices.map((service, index) => (
            <Card 
              key={index} 
              className={`relative overflow-hidden shadow-card hover:shadow-glow transition-all duration-300 hover:-translate-y-2 ${
                service.popular ? 'ring-2 ring-primary' : ''
              }`}
            >
              {/* Popular Badge */}
              {service.popular && (
                <div className="absolute top-4 right-4 z-10">
                  <Badge className="bg-primary text-primary-foreground">
                    Beliebt
                  </Badge>
                </div>
              )}

              {/* Header with Icon */}
              <CardHeader className="text-center pb-4">
                <div className="mx-auto w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-primary-foreground" />
                </div>
                <CardTitle className="text-2xl font-bold text-foreground mb-2">
                  {service.title}
                </CardTitle>
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{service.duration}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Price */}
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {service.price}
                  </div>
                </div>

                {/* Description */}
                <CardDescription className="text-center leading-relaxed">
                  {service.description}
                </CardDescription>

                {/* Features */}
                <div className="space-y-3">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Booking Button */}
                <Button
                  variant={service.popular ? "hero" : "professional"}
                  size="lg"
                  className="w-full"
                  onClick={() => window.open(service.bookingUrl, '_blank')}
                >
                  Buchung anfragen
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Info */}
        <div className="text-center mt-16">
          <Card className="max-w-md mx-auto p-8 bg-gradient-professional border border-border shadow-elegant">
            <h3 className="text-2xl font-bold text-professional-light-foreground mb-4">
              Fragen zu den Angeboten?
            </h3>
            <p className="text-professional-light-foreground mb-6">
              Ich berate dich gerne persönlich und finde gemeinsam mit dir die beste Behandlung.
            </p>
            <Button
              variant="elegant"
              size="lg"
              onClick={() => window.open('tel:0763611265', '_self')}
              className="w-full shadow-professional"
            >
              Jetzt anrufen: 076 361 12 65
            </Button>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default MassageServices;
import { Button } from "@/components/ui/button";
import { Heart, Phone, Menu, X } from "lucide-react";
import { useState } from "react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border shadow-card">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-foreground tracking-tight">Kunz</span>
              <span className="text-sm text-muted-foreground -mt-1 font-medium">Gesundheit</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Über mich
            </button>
            <button 
              onClick={() => scrollToSection('services')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Angebote
            </button>
            <button 
              onClick={() => scrollToSection('massage-services')}
              className="text-foreground hover:text-primary transition-colors"
            >
              Massagen
            </button>
            <Button
              variant="hero"
              size="lg"
              onClick={() => window.open('tel:0763611265', '_self')}
              className="ml-4"
            >
              <Phone className="w-4 h-4 mr-2" />
              Termin buchen
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-foreground hover:text-primary transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border bg-background">
            <nav className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('home')}
                className="text-left text-foreground hover:text-primary transition-colors py-2"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="text-left text-foreground hover:text-primary transition-colors py-2"
              >
                Über mich
              </button>
              <button 
                onClick={() => scrollToSection('services')}
                className="text-left text-foreground hover:text-primary transition-colors py-2"
              >
                Angebote
              </button>
              <button 
                onClick={() => scrollToSection('massage-services')}
                className="text-left text-foreground hover:text-primary transition-colors py-2"
              >
                Massagen
              </button>
              <Button
                variant="hero"
                size="lg"
                onClick={() => window.open('tel:0763611265', '_self')}
                className="mt-4 w-full"
              >
                <Phone className="w-4 h-4 mr-2" />
                Termin buchen
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
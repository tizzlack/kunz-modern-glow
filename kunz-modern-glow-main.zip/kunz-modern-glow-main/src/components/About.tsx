import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Facebook, Instagram, Phone } from "lucide-react";
import yannickOriginal from "@/assets/yannick-original.jpg";

const About = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-professional-neutral">{/* ... keep existing code */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl shadow-card">
              <img
                src={yannickOriginal}
                alt="Yannick Cyrill Kunz - Dipl. Berufsmasseur"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
            
            {/* Floating Credentials Card */}
            <Card className="absolute -bottom-6 -right-6 p-6 bg-card shadow-elegant border border-border">
              <div className="flex flex-col space-y-2">
                <Badge variant="outline" className="text-primary border-primary font-medium">
                  Dipl. Berufsmasseur
                </Badge>
                <Badge variant="outline" className="text-primary border-primary font-medium">
                  Schulmedizin Grundlage
                </Badge>
                <Badge variant="outline" className="text-primary border-primary font-medium">
                  MMA Trainer
                </Badge>
              </div>
            </Card>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
                Über mich
              </h2>
              <div className="w-20 h-1 bg-gradient-primary rounded-full mb-8"></div>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-primary">
                Yannick Cyrill Kunz
              </h3>
              
              <p className="text-lg text-muted-foreground leading-relaxed">
                Ich bin Yannick Cyrill Kunz, geboren am 23. Februar 1993 und bin Dipl. Berufsmasseur. 
                Als leidenschaftlicher Kampfsportler lege ich grossen Wert auf einen gesundheitsbewussten Lebensstil.
              </p>

              <div className="bg-gradient-professional p-6 rounded-xl border border-border">
                <p className="text-lg font-semibold text-professional-light-foreground mb-4">
                  "Gesundheit ist ein Prozess"
                </p>
                <p className="text-professional-light-foreground">
                  Steht für meine Überzeugung, dass geistiges, seelisches und körperliches Wohlbefinden 
                  durch kontinuierliche Pflege und Entwicklung erreicht wird. Mit meiner Arbeit helfe ich 
                  Menschen ihren Körper zu stärken und ihre Gesundheit langfristig zu fördern.
                </p>
              </div>

              {/* Social Links & Contact */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button
                  variant="hero"
                  size="lg"
                  onClick={() => window.open('tel:0763611265', '_self')}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  076 361 12 65
                </Button>
                
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => window.open('https://www.facebook.com/profile.php?id=61571743576514', '_blank')}
                  >
                    <Facebook className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                  >
                    <Instagram className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
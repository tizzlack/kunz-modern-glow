import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Sparkles, Leaf, ArrowRight } from "lucide-react";
import massageIcon from "@/assets/massage-icon.jpg";
import healthAbo from "@/assets/health-abo.jpg";
import vitalityOils from "@/assets/vitality-oils.jpg";

const Services = () => {
  const services = [
    {
      icon: Heart,
      title: "Massage",
      description: "Entdecke die wohltuende Wirkung meiner Massagen. Ob klassische Entspannung oder gezielte Muskelentspannung durch Sportmassage - gönn dir eine Auszeit, reduziere Stress und fördere dein gesundheitliches Gleichgewicht. Spüre die Balance, die durch gezielte Berührung entsteht.",
      image: massageIcon,
      buttonText: "Massage buchen",
      buttonAction: () => window.open('https://www.kunz-gesundheit.ch/book-online', '_blank')
    },
    {
      icon: Sparkles,
      title: "Gesundheits Abo",
      description: "Mit meinem Gesundheits-Abo profitierst du nicht nur von hochwertigen Produkten und Massagen, sondern erhältst auch eine klare Orientierung für deine Gesundheit - durch wissenschaftlich fundierte Tests, die dir zeigen, wo du stehst und wie du deine Gesundheitsziele erreichen kannst.",
      image: healthAbo,
      buttonText: "Abo anfragen",
      buttonAction: () => window.open('https://www.kunz-gesundheit.ch/book-online', '_blank')
    },
    {
      icon: Leaf,
      title: "Vitalitäts Angebote",
      description: "Meine Vitalitätsangebote von der Firma Zinzino sind mehr als nur Produkte, sie sind dein Schlüssel zu einem aktiven gesunden Lebensstil. Basierend auf neuesten Forschungen durch das Labor Vitas in Norwegen, biete ich dir massgeschneiderte Lösungen auf Zellebene, um dein Wohlbefinden zu steigern.",
      image: vitalityOils,
      buttonText: "Produkte ansehen",
      buttonAction: () => window.open('https://www.zinzino.com/shop/2016641913/CH/de-DE/products/shop', '_blank')
    }
  ];

  return (
    <section id="services" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Meine Angebote für Dich
          </h2>
          <div className="w-20 h-1 bg-gradient-primary rounded-full mx-auto mb-8"></div>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Mein Ziel ist es, dir mit meinen Angeboten zu mehr Wohlbefinden und innerer Balance zu verhelfen. 
            Schau dich um und entdecke, wie ich dich auf deinem Weg zur Gesundheit begleiten kann.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-8 lg:gap-12">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className={`overflow-hidden shadow-card hover:shadow-glow transition-all duration-300 ${
                index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
              } flex flex-col lg:flex`}
            >
              {/* Image */}
              <div className="lg:w-1/2 relative overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-64 lg:h-full object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/30 to-transparent"></div>
                
                {/* Icon Overlay */}
                <div className="absolute top-6 left-6 w-12 h-12 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <service.icon className="w-6 h-6 text-primary" />
                </div>
              </div>

              {/* Content */}
              <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
                <CardHeader className="p-0 mb-6">
                  <CardTitle className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                    {service.title}
                  </CardTitle>
                  <div className="w-16 h-1 bg-gradient-primary rounded-full"></div>
                </CardHeader>
                
                <CardContent className="p-0">
                  <CardDescription className="text-lg text-muted-foreground leading-relaxed mb-8">
                    {service.description}
                  </CardDescription>
                  
                  <Button
                    variant="hero"
                    size="lg"
                    onClick={service.buttonAction}
                    className="group shadow-professional"
                  >
                    {service.buttonText}
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
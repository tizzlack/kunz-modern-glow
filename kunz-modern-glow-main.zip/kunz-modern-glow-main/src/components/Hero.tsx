import { Button } from "@/components/ui/button";
import { Heart, Phone, ArrowRight } from "lucide-react";
import logoWatermark from "@/assets/logo-watermark.png";
import massageTherapy from "@/assets/massage-therapy.jpg";

const Hero = () => {
  const scrollToServices = () => {
    const element = document.getElementById('services');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${massageTherapy})` }}
      >
        <div className="absolute inset-0 bg-primary/85"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <div className="max-w-4xl mx-auto">
          {/* Logo Icon */}
          <div className="flex justify-center mb-8">
            <div className="w-24 h-24 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20 p-3 shadow-elegant">
              <img 
                src={logoWatermark} 
                alt="Kunz Gesundheit Logo" 
                className="w-full h-full object-contain filter brightness-0 invert opacity-90"
              />
            </div>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl lg:text-7xl font-bold mb-6 leading-tight tracking-tight">
            Kunz <span className="text-white/90">Gesundheit</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl lg:text-2xl mb-8 font-light opacity-95 tracking-wide">
            Gesundheit ist kein Zustand sondern ein Prozess
          </p>

          {/* Description */}
          <p className="text-lg lg:text-xl mb-12 max-w-3xl mx-auto leading-relaxed opacity-80">
            Jeder hält den Schlüssel zu seiner eigenen Heilung, aber manchmal braucht der Körper ein wenig Hilfe. 
            Genau das ist meine Berufung. Als Berufsmasseur und gesundheitsbewusster Mensch, arbeite ich eng mit Dir zusammen, 
            um dein körperliches, geistiges und seelisches Gleichgewicht wiederherzustellen und deine Mitte zu finden.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              variant="hero"
              size="xl"
              onClick={() => window.open('tel:0763611265', '_self')}
              className="bg-white text-primary hover:bg-white/95 shadow-elegant font-semibold"
            >
              <Phone className="w-5 h-5 mr-2" />
              Jetzt Termin buchen
            </Button>
            <Button
              variant="outline"
              size="xl"
              onClick={scrollToServices}
              className="border-white text-white hover:bg-white hover:text-primary"
            >
              Mehr erfahren
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;